If you have SNAP PRO - Please upload the contents of the zip file on the server and open snap-setup.php file from the browser. You will see the management panel.

Partial documentation is here: ​​http://www.nextscripts.com/snap-api/docs/

Complete documentation will be available with the final release.​​

Some sample codes are here: http://www.nextscripts.com/snap-api/
Here: http://www.nextscripts.com/google-plus-automated-posting/
Here: http://www.nextscripts.com/pinterest-automated-posting/